/** Classe représentant les liens entre equipement
 * 
 * @author Thibault Pichel & Yassine Kossir
 *
 */

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import javax.swing.*;


public class VueStation extends JFrame implements Observer
{
	private Station station;
	
	private JFrame fenetre;
	
	private final JButton abonnement = new JButton("Abonnement");
	private final JButton creationCanal = new JButton("Creer un canal");
	private final JButton rechercher = new JButton("Rechercher");

	
	private JList<String> listeCanaux;
	
	private JTabbedPane onglet = new JTabbedPane();
	private JTabbedPane ZoneText = new JTabbedPane();

	private ArrayList<ZoneText> listZoneText = new ArrayList<ZoneText>();
	private ArrayList<ChampText> listChampText = new ArrayList<ChampText>();
	

	public VueStation(Station station)
	{
		this.station = station;
		this.station.addObserver(this);
		listeCanaux = new JList<String>(station.getCanauxDispo());
		
		this.fenetre = new JFrame(this.station.toString());
		this.fenetre.setLocation(800,200);
		
		//Construire la fenêtre des messages envoyes
		JPanel centrebou = new JPanel();
		centrebou.add(creationCanal);
		
		
		JPanel centre = new JPanel(new BorderLayout());
		
		centre.add(this.ZoneText,BorderLayout.CENTER);
		centre.add(centrebou,BorderLayout.NORTH);
		//centre.add(centre0,BorderLayout.CENTER);
		//centre.add(canauxcrees, BorderLayout.CENTER);
		JPanel centreSud = new JPanel();
		centre.add(centreSud,BorderLayout.SOUTH);
		

		
		JPanel ouest1 = new JPanel();
		ouest1.add(abonnement);
		
		JPanel ouest = new JPanel(new BorderLayout());
		ouest.add(rechercher, BorderLayout.NORTH);
		ouest.add(listeCanaux, BorderLayout.CENTER);
		ouest.add(ouest1, BorderLayout.SOUTH);
		
		
		
		//Assembler les différentes parties
		this.fenetre.getContentPane().add(ouest, BorderLayout.WEST);
		this.fenetre.getContentPane().add(onglet, BorderLayout.EAST);
		this.fenetre.getContentPane().add(centre, BorderLayout.CENTER);
		
		//Construire le contrôleur (gestion des évènements)
		this.fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
		//afficher la fenêtre
		this.fenetre.pack();//redimmensionner la fenetre
		this.fenetre.setVisible(true);
		this.fenetre.setSize(400,200);

		
		this.creationCanal.addActionListener(new ActionCreer());
		this.rechercher.addActionListener(new ActionRechercher());
		this.abonnement.addActionListener(new ActionAbonnement());
		
		
		
	}
	
	public void update(Observable arg0, Object arg1)
	{
		if(arg1 instanceof Onglet)
		{
			this.creerOngletDiffusion((Onglet) arg1);
		}
		else if(arg1 instanceof String)
		{
			String[] donnees = ((String) arg1).split("@");
			for (ZoneText area : listZoneText)
			{
				if(area.getClef().equals(donnees[0]))
				{
					area.append(donnees[1]+"\n");
				}
			}
		}
	}

	public void creerOngletDiffusion(Onglet aAjouter)
	{
		String clef = aAjouter.getClef();
		
		JPanel zoneChampText = new JPanel();
		JButton diffuser = new JButton("Diffuser");
		ChampText champ = new ChampText(5, clef);
		listChampText.add(champ);
		zoneChampText.add(champ);
		zoneChampText.add(diffuser);
		
		JPanel onglet3 = new JPanel(new BorderLayout());
		ZoneText test = new ZoneText(15, 10, clef);
		listZoneText.add(test);
		onglet3.add(new JScrollPane(test),BorderLayout.CENTER);
		JPanel onglet3Sud = new JPanel(new BorderLayout());
		onglet3Sud.add(zoneChampText, BorderLayout.CENTER);
		JButton fermerCanal = new JButton("Fermer le canal");
		onglet3Sud.add(fermerCanal, BorderLayout.SOUTH);
		onglet3.add(onglet3Sud, BorderLayout.SOUTH);
		onglet3.add(new JLabel("Liste des messages envoyes"), BorderLayout.NORTH);
		
		this.ZoneText.add(clef,onglet3);
		
		fermerCanal.addActionListener(new ActionFermer());
		diffuser.addActionListener(new ActionDiffuser());	
	}
	
	public class ActionCreer implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0)
		{
			try
			{
				station.creationCanal();
			}
			catch (PasDeRouteurLocalException e)
			{
				e.printStackTrace();
			}
		}
	}
	
	public class ActionRechercher implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0)
		{
			try
			{
				station.canauxDispo();
			}
			catch (PasDeRouteurLocalException e)
			{
				JOptionPane.showMessageDialog(fenetre, e, "Pas de routeur local", JOptionPane.WARNING_MESSAGE);
			}
		}
	}
	
	
	public class ActionAbonnement implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0)
		{
			try
			{
				String clef = station.getCanauxDispo().get(listeCanaux.getSelectedIndex());
				
				try {
					station.abonnement(clef);
				} catch (PasDeRouteurLocalException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				JPanel onglet2 = new JPanel(new BorderLayout());
				ZoneText zone = new ZoneText(14,10, clef);
				listZoneText.add(zone);
				onglet2.add(new JLabel("Liste des messages recus"), BorderLayout.NORTH);
				onglet2.add(new JScrollPane(zone), BorderLayout.CENTER);
				JButton desabonnement = new JButton("Desabonnement");
				onglet2.add(desabonnement, BorderLayout.SOUTH);
				desabonnement.addActionListener(new ActionDesabonnement(clef));
				onglet.addTab(clef, onglet2);
			}
			catch (IndexOutOfBoundsException e)
			{
				int tailleList = listeCanaux.getLastVisibleIndex();
				if (tailleList == -1)
				{
					JOptionPane.showMessageDialog(fenetre, "La liste des canaux disponible est vide", "Liste vide", JOptionPane.WARNING_MESSAGE);
				}
				else
				{
					JOptionPane.showMessageDialog(fenetre, "Veuillez selectioner un canal auquel s'abonner", "Erreur de selection", JOptionPane.WARNING_MESSAGE);
				}
			}
		}	
	}
	
	public class ActionDesabonnement implements ActionListener
	{
		String clef;
		
		public ActionDesabonnement(String clef)
		{
			this.clef = clef;
		}
		
		public void actionPerformed(ActionEvent arg0)
		{
			try {
				station.desabonnement(clef);
			} catch (PasDeRouteurLocalException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			onglet.remove(onglet.getSelectedIndex());
		}
	}
	
	public class ActionDiffuser implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0)
		{
			int indiceOnglet = ZoneText.getSelectedIndex();
			String clef = ZoneText.getTitleAt(indiceOnglet);
			for (ChampText area : listChampText)
			{
				if(area.getClef().equals(clef))
				{
					try {
						station.envoyerDonnees(area.getText(), ZoneText.getTitleAt(indiceOnglet));
					} catch (PasDeRouteurLocalException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					area.setText("");
				}
			}

		}
	}
	
	public class ActionFermer implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0)
		{
			int indiceOnglet = ZoneText.getSelectedIndex();
			station.fermerCanal(ZoneText.getTitleAt(indiceOnglet));
			ZoneText.remove(indiceOnglet);
		}
	}
	

	public class ZoneText extends JTextArea
	{
		private String clef;
		
		public ZoneText(int x, int y, String clef)
		{
			super(x, y);
			this.clef=clef;
		}
		
		public String getClef()
		{
			return this.clef;
		}
	}
	
	public class ChampText extends JTextField
	{
		private String clef;
		
		public ChampText(int x, String clef)
		{
			super(x);
			this.clef=clef;
		}
		
		public String getClef()
		{
			return this.clef;
		}
	}

}
